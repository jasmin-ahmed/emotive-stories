// Created with Squiffy 5.1.3
// https://github.com/textadventures/squiffy

(function(){
/* jshint quotmark: single */
/* jshint evil: true */

var squiffy = {};

(function () {
    'use strict';

    squiffy.story = {};

    var initLinkHandler = function () {
        var handleLink = function (link) {
            if (link.hasClass('disabled')) return;
            var passage = link.data('passage');
            var section = link.data('section');
            var rotateAttr = link.attr('data-rotate');
            var sequenceAttr = link.attr('data-sequence');
            if (passage) {
                disableLink(link);
                squiffy.set('_turncount', squiffy.get('_turncount') + 1);
                passage = processLink(passage);
                if (passage) {
                    currentSection.append('<hr/>');
                    squiffy.story.passage(passage);
                }
                var turnPassage = '@' + squiffy.get('_turncount');
                if (turnPassage in squiffy.story.section.passages) {
                    squiffy.story.passage(turnPassage);
                }
                if ('@last' in squiffy.story.section.passages && squiffy.get('_turncount')>= squiffy.story.section.passageCount) {
                    squiffy.story.passage('@last');
                }
            }
            else if (section) {
                currentSection.append('<hr/>');
                disableLink(link);
                section = processLink(section);
                squiffy.story.go(section);
            }
            else if (rotateAttr || sequenceAttr) {
                var result = rotate(rotateAttr || sequenceAttr, rotateAttr ? link.text() : '');
                link.html(result[0].replace(/&quot;/g, '"').replace(/&#39;/g, '\''));
                var dataAttribute = rotateAttr ? 'data-rotate' : 'data-sequence';
                link.attr(dataAttribute, result[1]);
                if (!result[1]) {
                    disableLink(link);
                }
                if (link.attr('data-attribute')) {
                    squiffy.set(link.attr('data-attribute'), result[0]);
                }
                squiffy.story.save();
            }
        };

        squiffy.ui.output.on('click', 'a.squiffy-link', function () {
            handleLink(jQuery(this));
        });

        squiffy.ui.output.on('keypress', 'a.squiffy-link', function (e) {
            if (e.which !== 13) return;
            handleLink(jQuery(this));
        });

        squiffy.ui.output.on('mousedown', 'a.squiffy-link', function (event) {
            event.preventDefault();
        });
    };

    var disableLink = function (link) {
        link.addClass('disabled');
        link.attr('tabindex', -1);
    }
    
    squiffy.story.begin = function () {
        if (!squiffy.story.load()) {
            squiffy.story.go(squiffy.story.start);
        }
    };

    var processLink = function(link) {
		link = String(link);
        var sections = link.split(',');
        var first = true;
        var target = null;
        sections.forEach(function (section) {
            section = section.trim();
            if (startsWith(section, '@replace ')) {
                replaceLabel(section.substring(9));
            }
            else {
                if (first) {
                    target = section;
                }
                else {
                    setAttribute(section);
                }
            }
            first = false;
        });
        return target;
    };

    var setAttribute = function(expr) {
        var lhs, rhs, op, value;
        var setRegex = /^([\w]*)\s*=\s*(.*)$/;
        var setMatch = setRegex.exec(expr);
        if (setMatch) {
            lhs = setMatch[1];
            rhs = setMatch[2];
            if (isNaN(rhs)) {
				if(startsWith(rhs,"@")) rhs=squiffy.get(rhs.substring(1));
                squiffy.set(lhs, rhs);
            }
            else {
                squiffy.set(lhs, parseFloat(rhs));
            }
        }
        else {
			var incDecRegex = /^([\w]*)\s*([\+\-\*\/])=\s*(.*)$/;
            var incDecMatch = incDecRegex.exec(expr);
            if (incDecMatch) {
                lhs = incDecMatch[1];
                op = incDecMatch[2];
				rhs = incDecMatch[3];
				if(startsWith(rhs,"@")) rhs=squiffy.get(rhs.substring(1));
				rhs = parseFloat(rhs);
                value = squiffy.get(lhs);
                if (value === null) value = 0;
                if (op == '+') {
                    value += rhs;
                }
                if (op == '-') {
                    value -= rhs;
                }
				if (op == '*') {
					value *= rhs;
				}
				if (op == '/') {
					value /= rhs;
				}
                squiffy.set(lhs, value);
            }
            else {
                value = true;
                if (startsWith(expr, 'not ')) {
                    expr = expr.substring(4);
                    value = false;
                }
                squiffy.set(expr, value);
            }
        }
    };

    var replaceLabel = function(expr) {
        var regex = /^([\w]*)\s*=\s*(.*)$/;
        var match = regex.exec(expr);
        if (!match) return;
        var label = match[1];
        var text = match[2];
        if (text in squiffy.story.section.passages) {
            text = squiffy.story.section.passages[text].text;
        }
        else if (text in squiffy.story.sections) {
            text = squiffy.story.sections[text].text;
        }
        var stripParags = /^<p>(.*)<\/p>$/;
        var stripParagsMatch = stripParags.exec(text);
        if (stripParagsMatch) {
            text = stripParagsMatch[1];
        }
        var $labels = squiffy.ui.output.find('.squiffy-label-' + label);
        $labels.fadeOut(1000, function() {
            $labels.html(squiffy.ui.processText(text));
            $labels.fadeIn(1000, function() {
                squiffy.story.save();
            });
        });
    };

    squiffy.story.go = function(section) {
        squiffy.set('_transition', null);
        newSection();
        squiffy.story.section = squiffy.story.sections[section];
        if (!squiffy.story.section) return;
        squiffy.set('_section', section);
        setSeen(section);
        var master = squiffy.story.sections[''];
        if (master) {
            squiffy.story.run(master);
            squiffy.ui.write(master.text);
        }
        squiffy.story.run(squiffy.story.section);
        // The JS might have changed which section we're in
        if (squiffy.get('_section') == section) {
            squiffy.set('_turncount', 0);
            squiffy.ui.write(squiffy.story.section.text);
            squiffy.story.save();
        }
    };

    squiffy.story.run = function(section) {
        if (section.clear) {
            squiffy.ui.clearScreen();
        }
        if (section.attributes) {
            processAttributes(section.attributes);
        }
        if (section.js) {
            section.js();
        }
    };

    squiffy.story.passage = function(passageName) {
        var passage = squiffy.story.section.passages[passageName];
        if (!passage) return;
        setSeen(passageName);
        var masterSection = squiffy.story.sections[''];
        if (masterSection) {
            var masterPassage = masterSection.passages[''];
            if (masterPassage) {
                squiffy.story.run(masterPassage);
                squiffy.ui.write(masterPassage.text);
            }
        }
        var master = squiffy.story.section.passages[''];
        if (master) {
            squiffy.story.run(master);
            squiffy.ui.write(master.text);
        }
        squiffy.story.run(passage);
        squiffy.ui.write(passage.text);
        squiffy.story.save();
    };

    var processAttributes = function(attributes) {
        attributes.forEach(function (attribute) {
            if (startsWith(attribute, '@replace ')) {
                replaceLabel(attribute.substring(9));
            }
            else {
                setAttribute(attribute);
            }
        });
    };

    squiffy.story.restart = function() {
        if (squiffy.ui.settings.persist && window.localStorage) {
            var keys = Object.keys(localStorage);
            jQuery.each(keys, function (idx, key) {
                if (startsWith(key, squiffy.story.id)) {
                    localStorage.removeItem(key);
                }
            });
        }
        else {
            squiffy.storageFallback = {};
        }
        if (squiffy.ui.settings.scroll === 'element') {
            squiffy.ui.output.html('');
            squiffy.story.begin();
        }
        else {
            location.reload();
        }
    };

    squiffy.story.save = function() {
        squiffy.set('_output', squiffy.ui.output.html());
    };

    squiffy.story.load = function() {
        var output = squiffy.get('_output');
        if (!output) return false;
        squiffy.ui.output.html(output);
        currentSection = jQuery('#' + squiffy.get('_output-section'));
        squiffy.story.section = squiffy.story.sections[squiffy.get('_section')];
        var transition = squiffy.get('_transition');
        if (transition) {
            eval('(' + transition + ')()');
        }
        return true;
    };

    var setSeen = function(sectionName) {
        var seenSections = squiffy.get('_seen_sections');
        if (!seenSections) seenSections = [];
        if (seenSections.indexOf(sectionName) == -1) {
            seenSections.push(sectionName);
            squiffy.set('_seen_sections', seenSections);
        }
    };

    squiffy.story.seen = function(sectionName) {
        var seenSections = squiffy.get('_seen_sections');
        if (!seenSections) return false;
        return (seenSections.indexOf(sectionName) > -1);
    };
    
    squiffy.ui = {};

    var currentSection = null;
    var screenIsClear = true;
    var scrollPosition = 0;

    var newSection = function() {
        if (currentSection) {
            disableLink(jQuery('.squiffy-link', currentSection));
        }
        var sectionCount = squiffy.get('_section-count') + 1;
        squiffy.set('_section-count', sectionCount);
        var id = 'squiffy-section-' + sectionCount;
        currentSection = jQuery('<div/>', {
            id: id,
        }).appendTo(squiffy.ui.output);
        squiffy.set('_output-section', id);
    };

    squiffy.ui.write = function(text) {
        screenIsClear = false;
        scrollPosition = squiffy.ui.output.height();
        currentSection.append(jQuery('<div/>').html(squiffy.ui.processText(text)));
        squiffy.ui.scrollToEnd();
    };

    squiffy.ui.clearScreen = function() {
        squiffy.ui.output.html('');
        screenIsClear = true;
        newSection();
    };

    squiffy.ui.scrollToEnd = function() {
        var scrollTo, currentScrollTop, distance, duration;
        if (squiffy.ui.settings.scroll === 'element') {
            scrollTo = squiffy.ui.output[0].scrollHeight - squiffy.ui.output.height();
            currentScrollTop = squiffy.ui.output.scrollTop();
            if (scrollTo > currentScrollTop) {
                distance = scrollTo - currentScrollTop;
                duration = distance / 0.4;
                squiffy.ui.output.stop().animate({ scrollTop: scrollTo }, duration);
            }
        }
        else {
            scrollTo = scrollPosition;
            currentScrollTop = Math.max(jQuery('body').scrollTop(), jQuery('html').scrollTop());
            if (scrollTo > currentScrollTop) {
                var maxScrollTop = jQuery(document).height() - jQuery(window).height();
                if (scrollTo > maxScrollTop) scrollTo = maxScrollTop;
                distance = scrollTo - currentScrollTop;
                duration = distance / 0.5;
                jQuery('body,html').stop().animate({ scrollTop: scrollTo }, duration);
            }
        }
    };

    squiffy.ui.processText = function(text) {
        function process(text, data) {
            var containsUnprocessedSection = false;
            var open = text.indexOf('{');
            var close;
            
            if (open > -1) {
                var nestCount = 1;
                var searchStart = open + 1;
                var finished = false;
             
                while (!finished) {
                    var nextOpen = text.indexOf('{', searchStart);
                    var nextClose = text.indexOf('}', searchStart);
         
                    if (nextClose > -1) {
                        if (nextOpen > -1 && nextOpen < nextClose) {
                            nestCount++;
                            searchStart = nextOpen + 1;
                        }
                        else {
                            nestCount--;
                            searchStart = nextClose + 1;
                            if (nestCount === 0) {
                                close = nextClose;
                                containsUnprocessedSection = true;
                                finished = true;
                            }
                        }
                    }
                    else {
                        finished = true;
                    }
                }
            }
            
            if (containsUnprocessedSection) {
                var section = text.substring(open + 1, close);
                var value = processTextCommand(section, data);
                text = text.substring(0, open) + value + process(text.substring(close + 1), data);
            }
            
            return (text);
        }

        function processTextCommand(text, data) {
            if (startsWith(text, 'if ')) {
                return processTextCommand_If(text, data);
            }
            else if (startsWith(text, 'else:')) {
                return processTextCommand_Else(text, data);
            }
            else if (startsWith(text, 'label:')) {
                return processTextCommand_Label(text, data);
            }
            else if (/^rotate[: ]/.test(text)) {
                return processTextCommand_Rotate('rotate', text, data);
            }
            else if (/^sequence[: ]/.test(text)) {
                return processTextCommand_Rotate('sequence', text, data);   
            }
            else if (text in squiffy.story.section.passages) {
                return process(squiffy.story.section.passages[text].text, data);
            }
            else if (text in squiffy.story.sections) {
                return process(squiffy.story.sections[text].text, data);
            }
			else if (startsWith(text,'@') && !startsWith(text,'@replace')) {
				processAttributes(text.substring(1).split(","));
				return "";
			}
            return squiffy.get(text);
        }

        function processTextCommand_If(section, data) {
            var command = section.substring(3);
            var colon = command.indexOf(':');
            if (colon == -1) {
                return ('{if ' + command + '}');
            }

            var text = command.substring(colon + 1);
            var condition = command.substring(0, colon);
			condition = condition.replace("<", "&lt;");
            var operatorRegex = /([\w ]*)(=|&lt;=|&gt;=|&lt;&gt;|&lt;|&gt;)(.*)/;
            var match = operatorRegex.exec(condition);

            var result = false;

            if (match) {
                var lhs = squiffy.get(match[1]);
                var op = match[2];
                var rhs = match[3];

				if(startsWith(rhs,'@')) rhs=squiffy.get(rhs.substring(1));
				
                if (op == '=' && lhs == rhs) result = true;
                if (op == '&lt;&gt;' && lhs != rhs) result = true;
                if (op == '&gt;' && lhs > rhs) result = true;
                if (op == '&lt;' && lhs < rhs) result = true;
                if (op == '&gt;=' && lhs >= rhs) result = true;
                if (op == '&lt;=' && lhs <= rhs) result = true;
            }
            else {
                var checkValue = true;
                if (startsWith(condition, 'not ')) {
                    condition = condition.substring(4);
                    checkValue = false;
                }

                if (startsWith(condition, 'seen ')) {
                    result = (squiffy.story.seen(condition.substring(5)) == checkValue);
                }
                else {
                    var value = squiffy.get(condition);
                    if (value === null) value = false;
                    result = (value == checkValue);
                }
            }

            var textResult = result ? process(text, data) : '';

            data.lastIf = result;
            return textResult;
        }

        function processTextCommand_Else(section, data) {
            if (!('lastIf' in data) || data.lastIf) return '';
            var text = section.substring(5);
            return process(text, data);
        }

        function processTextCommand_Label(section, data) {
            var command = section.substring(6);
            var eq = command.indexOf('=');
            if (eq == -1) {
                return ('{label:' + command + '}');
            }

            var text = command.substring(eq + 1);
            var label = command.substring(0, eq);

            return '<span class="squiffy-label-' + label + '">' + process(text, data) + '</span>';
        }

        function processTextCommand_Rotate(type, section, data) {
            var options;
            var attribute = '';
            if (section.substring(type.length, type.length + 1) == ' ') {
                var colon = section.indexOf(':');
                if (colon == -1) {
                    return '{' + section + '}';
                }
                options = section.substring(colon + 1);
                attribute = section.substring(type.length + 1, colon);
            }
            else {
                options = section.substring(type.length + 1);
            }
            var rotation = rotate(options.replace(/"/g, '&quot;').replace(/'/g, '&#39;'));
            if (attribute) {
                squiffy.set(attribute, rotation[0]);
            }
            return '<a class="squiffy-link" data-' + type + '="' + rotation[1] + '" data-attribute="' + attribute + '" role="link">' + rotation[0] + '</a>';
        }

        var data = {
            fulltext: text
        };
        return process(text, data);
    };

    squiffy.ui.transition = function(f) {
        squiffy.set('_transition', f.toString());
        f();
    };

    squiffy.storageFallback = {};

    squiffy.set = function(attribute, value) {
        if (typeof value === 'undefined') value = true;
        if (squiffy.ui.settings.persist && window.localStorage) {
            localStorage[squiffy.story.id + '-' + attribute] = JSON.stringify(value);
        }
        else {
            squiffy.storageFallback[attribute] = JSON.stringify(value);
        }
        squiffy.ui.settings.onSet(attribute, value);
    };

    squiffy.get = function(attribute) {
        var result;
        if (squiffy.ui.settings.persist && window.localStorage) {
            result = localStorage[squiffy.story.id + '-' + attribute];
        }
        else {
            result = squiffy.storageFallback[attribute];
        }
        if (!result) return null;
        return JSON.parse(result);
    };

    var startsWith = function(string, prefix) {
        return string.substring(0, prefix.length) === prefix;
    };

    var rotate = function(options, current) {
        var colon = options.indexOf(':');
        if (colon == -1) {
            return [options, current];
        }
        var next = options.substring(0, colon);
        var remaining = options.substring(colon + 1);
        if (current) remaining += ':' + current;
        return [next, remaining];
    };

    var methods = {
        init: function (options) {
            var settings = jQuery.extend({
                scroll: 'body',
                persist: true,
                restartPrompt: true,
                onSet: function (attribute, value) {}
            }, options);

            squiffy.ui.output = this;
            squiffy.ui.restart = jQuery(settings.restart);
            squiffy.ui.settings = settings;

            if (settings.scroll === 'element') {
                squiffy.ui.output.css('overflow-y', 'auto');
            }

            initLinkHandler();
            squiffy.story.begin();
            
            return this;
        },
        get: function (attribute) {
            return squiffy.get(attribute);
        },
        set: function (attribute, value) {
            squiffy.set(attribute, value);
        },
        restart: function () {
            if (!squiffy.ui.settings.restartPrompt || confirm('Are you sure you want to restart?')) {
                squiffy.story.restart();
            }
        }
    };

    jQuery.fn.squiffy = function (methodOrOptions) {
        if (methods[methodOrOptions]) {
            return methods[methodOrOptions]
                .apply(this, Array.prototype.slice.call(arguments, 1));
        }
        else if (typeof methodOrOptions === 'object' || ! methodOrOptions) {
            return methods.init.apply(this, arguments);
        } else {
            jQuery.error('Method ' +  methodOrOptions + ' does not exist');
        }
    };
})();

var get = squiffy.get;
var set = squiffy.set;


squiffy.story.start = '_default';
squiffy.story.id = 'f3c480e666';
squiffy.story.sections = {
	'_default': {
		'text': "<p style=\"font-family: Times New Roman\"><b>Description:</b> Mike was born in the early 1930s and was a child when WWII began. He didn’t grow up with many toys, but those he had, he cherished plenty. He looks back fondly on the toys and explains the deep connection he has with all of them.</p>\n\n<p style=\"font-family: Times New Roman\">This game was created for research purposes as part of a MA thesis at the University of Graz. All images of objects were taken from <a href=\"https://dams.birminghammuseums.org.uk/asset-bank/action/viewDefaultHome?browseType=folders\" target=\"_blank\" rel=\"external\">Birmingham Museums Trust’s Digital Asset Resource</a> and are linked accordingly. Texts were adapted from object descriptions and Wikipedia and are also linked.</p> \n\n<h3 id=\"hello-nice-to-meet-you-and-welcome-to-birmingham-museum-and-art-gallery-\">Hello, nice to meet you and welcome to Birmingham Museum and Art Gallery!</h3>\n<p><a class=\"squiffy-link link-section\" data-section=\"_continue1\" role=\"link\" tabindex=\"0\">My name is Jesse and I’ll be your museum guide today.</a></p>",
		'passages': {
		},
	},
	'_continue1': {
		'text': "<p>It’s really pouring it down, isn’t it? Perfect day for a trip to the museum.</p>\n<p>Today’s exhibition is all about <strong>Childhood Toys &amp; Games</strong> and you’ll even meet <strong>Mike</strong> and hear all about his favourite WWII childhood toys. </p>\n<p>But we’ll get to all of that later! First, I’d like to tell you more about the museum itself.</p>\n<p>Let’s have a look at its <a class=\"squiffy-link link-section\" data-section=\"history\" role=\"link\" tabindex=\"0\">history</a> together.</p>",
		'passages': {
		},
	},
	'history': {
		'text': "<p><a href=\"https://www.birminghammuseums.org.uk/birmingham-museum-and-art-gallery\" target=\"_blank\">Birmingham Museum and Art Gallery</a> is housed in a Grade II* listed landmark building. The building has watched over Birmingham&#39;s Chamberlain and Victoria Squares since 1885. </p>\n<p>It has impressive collections, including its unrivalled Pre-Raphaelite collection featuring more than 2,000 awe-inspiring pieces by the likes of William Morris, Dante Gabriel Rossetti, and Edward Burne-Jones. </p>\n<p>The museum’s collection is one of the city&#39;s greatest cultural assets. It consists of around 800,000 objects and is displayed and stored in nine venues. The collection includes art and design, human history, natural science, and science and industry. </p>\n<p>Would you like to see what the <a class=\"squiffy-link link-passage\" data-passage=\"Industrial Hall\" role=\"link\" tabindex=\"0\">Industrial Hall</a> in Birmingham Museum &amp; Art Gallery looked like in 1906 compared to today? </p>",
		'passages': {
			'Industrial Hall': {
				'text': "<p><strong>Click on the image below</strong> and compare <a class=\"squiffy-link link-passage\" data-passage=\"a picture of the Industrial Hall in Birmingham Museum & Art Gallery taken in 2018\" role=\"link\" tabindex=\"0\">a picture of the Industrial Hall in Birmingham Museum &amp; Art Gallery taken in 2018</a> to <a class=\"squiffy-link link-passage\" data-passage=\"a postcard of the same Industrial Hall from 1906\" role=\"link\" tabindex=\"0\">a postcard of the same Industrial Hall from 1906</a>. The juxtaposition GIF was created with <a href=\"https://juxtapose.knightlab.com/\" target=\"_blank\">this tool</a>. Alternatively, you can find an interactive version of the juxtaposition <a href=\"https://cdn.knightlab.com/libs/juxtapose/latest/embed/index.html?uid=f363a5fc-6c05-11ed-b5bd-6595d9b17862\" target=\"_blank\">here</a>.</p>\n<p><a href=\"https://imgbox.com/SE1amXsP\" target=\"_blank\"><img src=\"https://thumbs2.imgbox.com/5d/e5/SE1amXsP_t.gif\" alt=\"image host\"/></a></p>\n<p>When you&#39;ve looked at the images, head over to <a class=\"squiffy-link link-section\" data-section=\"Mike's Story\" role=\"link\" tabindex=\"0\">Mike&#39;s Story</a> at the Childhood Toys and Games exhibit!</p>",
			},
			'a picture of the Industrial Hall in Birmingham Museum & Art Gallery taken in 2018': {
				'text': "<p>This picture was taken from <a href=\"https://commons.wikimedia.org/wiki/File:Birmingham_Museum_and_Art_Gallery_Industrial_Gallery.jpg\" target=\"_blank\">Wikimedia Commons</a>. </p>",
			},
			'a postcard of the same Industrial Hall from 1906': {
				'text': "<p>Find out more about <a href=\"https://dams.birminghammuseums.org.uk/asset-bank/action/viewAsset?id=12305&index=0&total=12&view=viewSearchItem\" target=\"_blank\">this object</a> over at Birmingham Museums Trust’s Digital Asset Resource.</p>",
			},
		},
	},
	'Mike\'s Story': {
		'text': "<h3 id=\"hello-my-name-is-mike-\">Hello! My name is Mike.</h3>\n<p>I was born in the year of 1938. As you well know, it was in the early 1930s that WWII began. My parents tried to shelter me and my siblings as best as they could. </p>\n<p>We didn&#39;t grow up with many toys or games, but what we had we cherished and passed on through the generations. </p>\n<p>I would like to show you <a class=\"squiffy-link link-section\" data-section=\"my favourite tin toys\" role=\"link\" tabindex=\"0\">my favourite tin toys</a> first. </p>",
		'passages': {
		},
	},
	'my favourite tin toys': {
		'text': "<h3 id=\"christmas-present-1947-br-\"><strong>Christmas Present 1947:</strong> <br/></h3>\n<p><a href=\"https://imgbox.com/VpMltEqM\" target=\"_blank\"><img src=\"https://thumbs2.imgbox.com/34/25/VpMltEqM_t.jpg\" alt=\"imgbox\"/></a> </p>\n<p>This was a Christmas present I received right after my father was promoted at his job. It&#39;s a marvellous <a class=\"squiffy-link link-passage\" data-passage=\"toy motorcycle\" role=\"link\" tabindex=\"0\">toy motorcycle</a> made by <a class=\"squiffy-link link-passage\" data-passage=\"Mettoy Co.\" role=\"link\" tabindex=\"0\">Mettoy Co.</a> It&#39;s still in great condition, even though my daughter played with it as well, and let me tell you, she didn&#39;t go easy on the motorcycle! </p>\n<p>Let&#39;s have a look at the <a class=\"squiffy-link link-passage\" data-passage=\"next toy\" role=\"link\" tabindex=\"0\">next toy</a>.</p>",
		'passages': {
			'toy motorcycle': {
				'text': "<p>Find out more about <a href=\"https://dams.birminghammuseums.org.uk/asset-bank/action/viewAsset?id=23175&index=7&total=48&view=viewSearchItem\" target=\"_blank\">this object</a> over at Birmingham Museum &amp; Art Gallery&#39;s digital collection.</p>",
			},
			'Mettoy Co.': {
				'text': "<p>Mettoy Co. was a British manufacturing company founded in 1933 by Philip Ullmann and Arthur Katz. Both of them were German Jews who moved to Britain in 1933 after Hitler’s rise to power.</p>",
			},
			'next toy': {
				'text': "<h3 id=\"my-eldest-brother-s-toy-car-br-\"><strong>My Eldest Brother’s Toy Car</strong>: <br/></h3>\n<p><a href=\"https://imgbox.com/VnCc7DRS\" target=\"_blank\"><img src=\"https://thumbs2.imgbox.com/3c/70/VnCc7DRS_t.jpg\" alt=\"imgbox\"/></a> </p>\n<p>This was my eldest brother&#39;s <a class=\"squiffy-link link-passage\" data-passage=\"toy car\" role=\"link\" tabindex=\"0\">toy car</a>. I was rather jealous of it at the time as he would ever let me play with it. It was manufactured by <a class=\"squiffy-link link-passage\" data-passage=\"Alfred Wells & Co.\" role=\"link\" tabindex=\"0\">Alfred Wells &amp; Co.</a> </p>\n<p>Up next, a <a class=\"squiffy-link link-passage\" data-passage=\"tinplate toy racing car\" role=\"link\" tabindex=\"0\">tinplate toy racing car</a>!</p>",
			},
			'toy car': {
				'text': "<p>Find out more about <a href=\"https://dams.birminghammuseums.org.uk/asset-bank/action/viewAsset?id=23180&index=4&total=48&view=viewSearchItem\" target=\"_blank\">this object</a> over at Birmingham Museum &amp; Art Gallery&#39;s digital collection.</p>",
			},
			'Alfred Wells & Co.': {
				'text': "<p>Alfred Wells &amp; Co. was a British manufacturing company founded in 1919, specialising on mechanical toys. The company also launched several tin toys.</p>",
			},
			'tinplate toy racing car': {
				'text': "<h3 id=\"my-first-own-toy-car-br-\"><strong>My First Own Toy Car</strong>: <br/></h3>\n<p><a href=\"https://imgbox.com/kbmf31lF\" target=\"_blank\"><img src=\"https://thumbs2.imgbox.com/26/71/kbmf31lF_t.jpg\" alt=\"imgbox\"/></a> </p>\n<p>My firs town <a class=\"squiffy-link link-passage\" data-passage=\"toy racing car\" role=\"link\" tabindex=\"0\">toy racing car</a> manufactured by Mettoy Co. was a birthday present. Suddenly, my brother was jealous of my racing car! He never let me play with his car, so I was very territorial over my racing car, too. </p>\n<p>Shall we move on to more <a class=\"squiffy-link link-section\" data-section=\"cuddly toys\" role=\"link\" tabindex=\"0\">cuddly toys</a>?</p>",
			},
			'toy racing car': {
				'text': "<p>Find out more about <a href=\"https://dams.birminghammuseums.org.uk/asset-bank/action/viewAsset?id=23184&index=14&total=48&view=viewSearchItem\" target=\"_blank\">this object</a> this object over at Birmingham Museum &amp; Art Gallery&#39;s digital collection.</p>",
			},
		},
	},
	'cuddly toys': {
		'text': "<h3 id=\"my-first-teddy-bear-made-by-mum-br-\"><strong>My first Teddy Bear Made by Mum</strong>: <br/></h3>\n<p><a href=\"https://imgbox.com/WDbSNu0d\" target=\"_blank\"><img src=\"https://thumbs2.imgbox.com/9a/e6/WDbSNu0d_t.jpg\" alt=\"imgbox\"/></a> </p>\n<p>This is my first own <a class=\"squiffy-link link-passage\" data-passage=\"hand-made teddy bear\" role=\"link\" tabindex=\"0\">hand-made teddy bear</a> I received in 1942. It was made by my mother out of a khaki woollen army blanket, and I named him Cuddles. He&#39;s still in great condition, don’t you think? </p>\n<p>Up next, <a class=\"squiffy-link link-passage\" data-passage=\"my last teddy\" role=\"link\" tabindex=\"0\">my last teddy</a>...</p>",
		'passages': {
			'hand-made teddy bear': {
				'text': "<p>Find out more about <a href=\"https://dams.birminghammuseums.org.uk/asset-bank/action/viewAsset?id=19738&index=2&total=48&view=viewSearchItem\" target=\"_blank\">this object</a> over at Birmingham Museum &amp; Art Gallery&#39;s digital collection.</p>",
			},
			'my last teddy': {
				'text': "<h3 id=\"my-last-teddy-bear-br-\"><strong>My Last Teddy Bear</strong>: <br/></h3>\n<p><a href=\"https://imgbox.com/IfkJHFdE\" target=\"_blank\"><img src=\"https://thumbs2.imgbox.com/22/ed/IfkJHFdE_t.jpg\" alt=\"imgbox\"/></a></p>\n<p>My last <a class=\"squiffy-link link-passage\" data-passage=\"shop-bought teddy bear\" role=\"link\" tabindex=\"0\">shop-bought teddy bear</a> given to me by my mother. This one was manufactured by <a class=\"squiffy-link link-passage\" data-passage=\"Chad Valley.\" role=\"link\" tabindex=\"0\">Chad Valley.</a> I&#39;m not sure he received enough love from me. At the time, I was a teenager and thought myself too old for stuffed animals. But he spent his time next to Cuddles before he was passed on to my eldest daughter. I’m sure they went on many adventures together.</p>\n<p><a class=\"squiffy-link link-section\" data-section=\"Let's wrap this story up!\" role=\"link\" tabindex=\"0\">Let&#39;s wrap this story up!</a></p>",
			},
			'shop-bought teddy bear': {
				'text': "<p>Find out more about <a href=\"https://dams.birminghammuseums.org.uk/asset-bank/action/viewAsset?id=25120\" target=\"_blank\">this object</a> over at Birmingham Museum &amp; Art Gallery&#39;s digital collection.</p>",
			},
			'Chad Valley.': {
				'text': "<p>Chad Valley is a long-established British brand of toys owned by Sainsbury’s. The company has its roots in the early 19th century. They decided to expand their range to soft toys before WWI and began mass-producing teddy bears.</p>",
			},
		},
	},
	'Let\'s wrap this story up!': {
		'text': "<p>Now that you&#39;ve heard Mike&#39;s story... </p>\n<p><a class=\"squiffy-link link-section\" data-section=\"_continue2\" role=\"link\" tabindex=\"0\">I have a few questions for you!</a></p>",
		'passages': {
		},
	},
	'_continue2': {
		'text': "<h3 id=\"what-was-your-favourite-childhood-toy-can-you-name-one-specific-memory-you-have-with-it-do-you-still-own-the-toy-\">What was <strong>your</strong> favourite childhood toy? Can you name one specific memory you have with it? Do you still own the toy?</h3>",
		'passages': {
		},
	},
}
})();