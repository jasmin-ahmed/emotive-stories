// Created with Squiffy 5.1.3
// https://github.com/textadventures/squiffy

(function(){
/* jshint quotmark: single */
/* jshint evil: true */

var squiffy = {};

(function () {
    'use strict';

    squiffy.story = {};

    var initLinkHandler = function () {
        var handleLink = function (link) {
            if (link.hasClass('disabled')) return;
            var passage = link.data('passage');
            var section = link.data('section');
            var rotateAttr = link.attr('data-rotate');
            var sequenceAttr = link.attr('data-sequence');
            if (passage) {
                disableLink(link);
                squiffy.set('_turncount', squiffy.get('_turncount') + 1);
                passage = processLink(passage);
                if (passage) {
                    currentSection.append('<hr/>');
                    squiffy.story.passage(passage);
                }
                var turnPassage = '@' + squiffy.get('_turncount');
                if (turnPassage in squiffy.story.section.passages) {
                    squiffy.story.passage(turnPassage);
                }
                if ('@last' in squiffy.story.section.passages && squiffy.get('_turncount')>= squiffy.story.section.passageCount) {
                    squiffy.story.passage('@last');
                }
            }
            else if (section) {
                currentSection.append('<hr/>');
                disableLink(link);
                section = processLink(section);
                squiffy.story.go(section);
            }
            else if (rotateAttr || sequenceAttr) {
                var result = rotate(rotateAttr || sequenceAttr, rotateAttr ? link.text() : '');
                link.html(result[0].replace(/&quot;/g, '"').replace(/&#39;/g, '\''));
                var dataAttribute = rotateAttr ? 'data-rotate' : 'data-sequence';
                link.attr(dataAttribute, result[1]);
                if (!result[1]) {
                    disableLink(link);
                }
                if (link.attr('data-attribute')) {
                    squiffy.set(link.attr('data-attribute'), result[0]);
                }
                squiffy.story.save();
            }
        };

        squiffy.ui.output.on('click', 'a.squiffy-link', function () {
            handleLink(jQuery(this));
        });

        squiffy.ui.output.on('keypress', 'a.squiffy-link', function (e) {
            if (e.which !== 13) return;
            handleLink(jQuery(this));
        });

        squiffy.ui.output.on('mousedown', 'a.squiffy-link', function (event) {
            event.preventDefault();
        });
    };

    var disableLink = function (link) {
        link.addClass('disabled');
        link.attr('tabindex', -1);
    }
    
    squiffy.story.begin = function () {
        if (!squiffy.story.load()) {
            squiffy.story.go(squiffy.story.start);
        }
    };

    var processLink = function(link) {
		link = String(link);
        var sections = link.split(',');
        var first = true;
        var target = null;
        sections.forEach(function (section) {
            section = section.trim();
            if (startsWith(section, '@replace ')) {
                replaceLabel(section.substring(9));
            }
            else {
                if (first) {
                    target = section;
                }
                else {
                    setAttribute(section);
                }
            }
            first = false;
        });
        return target;
    };

    var setAttribute = function(expr) {
        var lhs, rhs, op, value;
        var setRegex = /^([\w]*)\s*=\s*(.*)$/;
        var setMatch = setRegex.exec(expr);
        if (setMatch) {
            lhs = setMatch[1];
            rhs = setMatch[2];
            if (isNaN(rhs)) {
				if(startsWith(rhs,"@")) rhs=squiffy.get(rhs.substring(1));
                squiffy.set(lhs, rhs);
            }
            else {
                squiffy.set(lhs, parseFloat(rhs));
            }
        }
        else {
			var incDecRegex = /^([\w]*)\s*([\+\-\*\/])=\s*(.*)$/;
            var incDecMatch = incDecRegex.exec(expr);
            if (incDecMatch) {
                lhs = incDecMatch[1];
                op = incDecMatch[2];
				rhs = incDecMatch[3];
				if(startsWith(rhs,"@")) rhs=squiffy.get(rhs.substring(1));
				rhs = parseFloat(rhs);
                value = squiffy.get(lhs);
                if (value === null) value = 0;
                if (op == '+') {
                    value += rhs;
                }
                if (op == '-') {
                    value -= rhs;
                }
				if (op == '*') {
					value *= rhs;
				}
				if (op == '/') {
					value /= rhs;
				}
                squiffy.set(lhs, value);
            }
            else {
                value = true;
                if (startsWith(expr, 'not ')) {
                    expr = expr.substring(4);
                    value = false;
                }
                squiffy.set(expr, value);
            }
        }
    };

    var replaceLabel = function(expr) {
        var regex = /^([\w]*)\s*=\s*(.*)$/;
        var match = regex.exec(expr);
        if (!match) return;
        var label = match[1];
        var text = match[2];
        if (text in squiffy.story.section.passages) {
            text = squiffy.story.section.passages[text].text;
        }
        else if (text in squiffy.story.sections) {
            text = squiffy.story.sections[text].text;
        }
        var stripParags = /^<p>(.*)<\/p>$/;
        var stripParagsMatch = stripParags.exec(text);
        if (stripParagsMatch) {
            text = stripParagsMatch[1];
        }
        var $labels = squiffy.ui.output.find('.squiffy-label-' + label);
        $labels.fadeOut(1000, function() {
            $labels.html(squiffy.ui.processText(text));
            $labels.fadeIn(1000, function() {
                squiffy.story.save();
            });
        });
    };

    squiffy.story.go = function(section) {
        squiffy.set('_transition', null);
        newSection();
        squiffy.story.section = squiffy.story.sections[section];
        if (!squiffy.story.section) return;
        squiffy.set('_section', section);
        setSeen(section);
        var master = squiffy.story.sections[''];
        if (master) {
            squiffy.story.run(master);
            squiffy.ui.write(master.text);
        }
        squiffy.story.run(squiffy.story.section);
        // The JS might have changed which section we're in
        if (squiffy.get('_section') == section) {
            squiffy.set('_turncount', 0);
            squiffy.ui.write(squiffy.story.section.text);
            squiffy.story.save();
        }
    };

    squiffy.story.run = function(section) {
        if (section.clear) {
            squiffy.ui.clearScreen();
        }
        if (section.attributes) {
            processAttributes(section.attributes);
        }
        if (section.js) {
            section.js();
        }
    };

    squiffy.story.passage = function(passageName) {
        var passage = squiffy.story.section.passages[passageName];
        if (!passage) return;
        setSeen(passageName);
        var masterSection = squiffy.story.sections[''];
        if (masterSection) {
            var masterPassage = masterSection.passages[''];
            if (masterPassage) {
                squiffy.story.run(masterPassage);
                squiffy.ui.write(masterPassage.text);
            }
        }
        var master = squiffy.story.section.passages[''];
        if (master) {
            squiffy.story.run(master);
            squiffy.ui.write(master.text);
        }
        squiffy.story.run(passage);
        squiffy.ui.write(passage.text);
        squiffy.story.save();
    };

    var processAttributes = function(attributes) {
        attributes.forEach(function (attribute) {
            if (startsWith(attribute, '@replace ')) {
                replaceLabel(attribute.substring(9));
            }
            else {
                setAttribute(attribute);
            }
        });
    };

    squiffy.story.restart = function() {
        if (squiffy.ui.settings.persist && window.localStorage) {
            var keys = Object.keys(localStorage);
            jQuery.each(keys, function (idx, key) {
                if (startsWith(key, squiffy.story.id)) {
                    localStorage.removeItem(key);
                }
            });
        }
        else {
            squiffy.storageFallback = {};
        }
        if (squiffy.ui.settings.scroll === 'element') {
            squiffy.ui.output.html('');
            squiffy.story.begin();
        }
        else {
            location.reload();
        }
    };

    squiffy.story.save = function() {
        squiffy.set('_output', squiffy.ui.output.html());
    };

    squiffy.story.load = function() {
        var output = squiffy.get('_output');
        if (!output) return false;
        squiffy.ui.output.html(output);
        currentSection = jQuery('#' + squiffy.get('_output-section'));
        squiffy.story.section = squiffy.story.sections[squiffy.get('_section')];
        var transition = squiffy.get('_transition');
        if (transition) {
            eval('(' + transition + ')()');
        }
        return true;
    };

    var setSeen = function(sectionName) {
        var seenSections = squiffy.get('_seen_sections');
        if (!seenSections) seenSections = [];
        if (seenSections.indexOf(sectionName) == -1) {
            seenSections.push(sectionName);
            squiffy.set('_seen_sections', seenSections);
        }
    };

    squiffy.story.seen = function(sectionName) {
        var seenSections = squiffy.get('_seen_sections');
        if (!seenSections) return false;
        return (seenSections.indexOf(sectionName) > -1);
    };
    
    squiffy.ui = {};

    var currentSection = null;
    var screenIsClear = true;
    var scrollPosition = 0;

    var newSection = function() {
        if (currentSection) {
            disableLink(jQuery('.squiffy-link', currentSection));
        }
        var sectionCount = squiffy.get('_section-count') + 1;
        squiffy.set('_section-count', sectionCount);
        var id = 'squiffy-section-' + sectionCount;
        currentSection = jQuery('<div/>', {
            id: id,
        }).appendTo(squiffy.ui.output);
        squiffy.set('_output-section', id);
    };

    squiffy.ui.write = function(text) {
        screenIsClear = false;
        scrollPosition = squiffy.ui.output.height();
        currentSection.append(jQuery('<div/>').html(squiffy.ui.processText(text)));
        squiffy.ui.scrollToEnd();
    };

    squiffy.ui.clearScreen = function() {
        squiffy.ui.output.html('');
        screenIsClear = true;
        newSection();
    };

    squiffy.ui.scrollToEnd = function() {
        var scrollTo, currentScrollTop, distance, duration;
        if (squiffy.ui.settings.scroll === 'element') {
            scrollTo = squiffy.ui.output[0].scrollHeight - squiffy.ui.output.height();
            currentScrollTop = squiffy.ui.output.scrollTop();
            if (scrollTo > currentScrollTop) {
                distance = scrollTo - currentScrollTop;
                duration = distance / 0.4;
                squiffy.ui.output.stop().animate({ scrollTop: scrollTo }, duration);
            }
        }
        else {
            scrollTo = scrollPosition;
            currentScrollTop = Math.max(jQuery('body').scrollTop(), jQuery('html').scrollTop());
            if (scrollTo > currentScrollTop) {
                var maxScrollTop = jQuery(document).height() - jQuery(window).height();
                if (scrollTo > maxScrollTop) scrollTo = maxScrollTop;
                distance = scrollTo - currentScrollTop;
                duration = distance / 0.5;
                jQuery('body,html').stop().animate({ scrollTop: scrollTo }, duration);
            }
        }
    };

    squiffy.ui.processText = function(text) {
        function process(text, data) {
            var containsUnprocessedSection = false;
            var open = text.indexOf('{');
            var close;
            
            if (open > -1) {
                var nestCount = 1;
                var searchStart = open + 1;
                var finished = false;
             
                while (!finished) {
                    var nextOpen = text.indexOf('{', searchStart);
                    var nextClose = text.indexOf('}', searchStart);
         
                    if (nextClose > -1) {
                        if (nextOpen > -1 && nextOpen < nextClose) {
                            nestCount++;
                            searchStart = nextOpen + 1;
                        }
                        else {
                            nestCount--;
                            searchStart = nextClose + 1;
                            if (nestCount === 0) {
                                close = nextClose;
                                containsUnprocessedSection = true;
                                finished = true;
                            }
                        }
                    }
                    else {
                        finished = true;
                    }
                }
            }
            
            if (containsUnprocessedSection) {
                var section = text.substring(open + 1, close);
                var value = processTextCommand(section, data);
                text = text.substring(0, open) + value + process(text.substring(close + 1), data);
            }
            
            return (text);
        }

        function processTextCommand(text, data) {
            if (startsWith(text, 'if ')) {
                return processTextCommand_If(text, data);
            }
            else if (startsWith(text, 'else:')) {
                return processTextCommand_Else(text, data);
            }
            else if (startsWith(text, 'label:')) {
                return processTextCommand_Label(text, data);
            }
            else if (/^rotate[: ]/.test(text)) {
                return processTextCommand_Rotate('rotate', text, data);
            }
            else if (/^sequence[: ]/.test(text)) {
                return processTextCommand_Rotate('sequence', text, data);   
            }
            else if (text in squiffy.story.section.passages) {
                return process(squiffy.story.section.passages[text].text, data);
            }
            else if (text in squiffy.story.sections) {
                return process(squiffy.story.sections[text].text, data);
            }
			else if (startsWith(text,'@') && !startsWith(text,'@replace')) {
				processAttributes(text.substring(1).split(","));
				return "";
			}
            return squiffy.get(text);
        }

        function processTextCommand_If(section, data) {
            var command = section.substring(3);
            var colon = command.indexOf(':');
            if (colon == -1) {
                return ('{if ' + command + '}');
            }

            var text = command.substring(colon + 1);
            var condition = command.substring(0, colon);
			condition = condition.replace("<", "&lt;");
            var operatorRegex = /([\w ]*)(=|&lt;=|&gt;=|&lt;&gt;|&lt;|&gt;)(.*)/;
            var match = operatorRegex.exec(condition);

            var result = false;

            if (match) {
                var lhs = squiffy.get(match[1]);
                var op = match[2];
                var rhs = match[3];

				if(startsWith(rhs,'@')) rhs=squiffy.get(rhs.substring(1));
				
                if (op == '=' && lhs == rhs) result = true;
                if (op == '&lt;&gt;' && lhs != rhs) result = true;
                if (op == '&gt;' && lhs > rhs) result = true;
                if (op == '&lt;' && lhs < rhs) result = true;
                if (op == '&gt;=' && lhs >= rhs) result = true;
                if (op == '&lt;=' && lhs <= rhs) result = true;
            }
            else {
                var checkValue = true;
                if (startsWith(condition, 'not ')) {
                    condition = condition.substring(4);
                    checkValue = false;
                }

                if (startsWith(condition, 'seen ')) {
                    result = (squiffy.story.seen(condition.substring(5)) == checkValue);
                }
                else {
                    var value = squiffy.get(condition);
                    if (value === null) value = false;
                    result = (value == checkValue);
                }
            }

            var textResult = result ? process(text, data) : '';

            data.lastIf = result;
            return textResult;
        }

        function processTextCommand_Else(section, data) {
            if (!('lastIf' in data) || data.lastIf) return '';
            var text = section.substring(5);
            return process(text, data);
        }

        function processTextCommand_Label(section, data) {
            var command = section.substring(6);
            var eq = command.indexOf('=');
            if (eq == -1) {
                return ('{label:' + command + '}');
            }

            var text = command.substring(eq + 1);
            var label = command.substring(0, eq);

            return '<span class="squiffy-label-' + label + '">' + process(text, data) + '</span>';
        }

        function processTextCommand_Rotate(type, section, data) {
            var options;
            var attribute = '';
            if (section.substring(type.length, type.length + 1) == ' ') {
                var colon = section.indexOf(':');
                if (colon == -1) {
                    return '{' + section + '}';
                }
                options = section.substring(colon + 1);
                attribute = section.substring(type.length + 1, colon);
            }
            else {
                options = section.substring(type.length + 1);
            }
            var rotation = rotate(options.replace(/"/g, '&quot;').replace(/'/g, '&#39;'));
            if (attribute) {
                squiffy.set(attribute, rotation[0]);
            }
            return '<a class="squiffy-link" data-' + type + '="' + rotation[1] + '" data-attribute="' + attribute + '" role="link">' + rotation[0] + '</a>';
        }

        var data = {
            fulltext: text
        };
        return process(text, data);
    };

    squiffy.ui.transition = function(f) {
        squiffy.set('_transition', f.toString());
        f();
    };

    squiffy.storageFallback = {};

    squiffy.set = function(attribute, value) {
        if (typeof value === 'undefined') value = true;
        if (squiffy.ui.settings.persist && window.localStorage) {
            localStorage[squiffy.story.id + '-' + attribute] = JSON.stringify(value);
        }
        else {
            squiffy.storageFallback[attribute] = JSON.stringify(value);
        }
        squiffy.ui.settings.onSet(attribute, value);
    };

    squiffy.get = function(attribute) {
        var result;
        if (squiffy.ui.settings.persist && window.localStorage) {
            result = localStorage[squiffy.story.id + '-' + attribute];
        }
        else {
            result = squiffy.storageFallback[attribute];
        }
        if (!result) return null;
        return JSON.parse(result);
    };

    var startsWith = function(string, prefix) {
        return string.substring(0, prefix.length) === prefix;
    };

    var rotate = function(options, current) {
        var colon = options.indexOf(':');
        if (colon == -1) {
            return [options, current];
        }
        var next = options.substring(0, colon);
        var remaining = options.substring(colon + 1);
        if (current) remaining += ':' + current;
        return [next, remaining];
    };

    var methods = {
        init: function (options) {
            var settings = jQuery.extend({
                scroll: 'body',
                persist: true,
                restartPrompt: true,
                onSet: function (attribute, value) {}
            }, options);

            squiffy.ui.output = this;
            squiffy.ui.restart = jQuery(settings.restart);
            squiffy.ui.settings = settings;

            if (settings.scroll === 'element') {
                squiffy.ui.output.css('overflow-y', 'auto');
            }

            initLinkHandler();
            squiffy.story.begin();
            
            return this;
        },
        get: function (attribute) {
            return squiffy.get(attribute);
        },
        set: function (attribute, value) {
            squiffy.set(attribute, value);
        },
        restart: function () {
            if (!squiffy.ui.settings.restartPrompt || confirm('Are you sure you want to restart?')) {
                squiffy.story.restart();
            }
        }
    };

    jQuery.fn.squiffy = function (methodOrOptions) {
        if (methods[methodOrOptions]) {
            return methods[methodOrOptions]
                .apply(this, Array.prototype.slice.call(arguments, 1));
        }
        else if (typeof methodOrOptions === 'object' || ! methodOrOptions) {
            return methods.init.apply(this, arguments);
        } else {
            jQuery.error('Method ' +  methodOrOptions + ' does not exist');
        }
    };
})();

var get = squiffy.get;
var set = squiffy.set;


squiffy.story.start = '_default';
squiffy.story.id = '52f1c2fbd4';
squiffy.story.sections = {
	'_default': {
		'text': "<p style=\"font-family: Times New Roman\"><b>Description:</b> Paul is facing a difficult decision: go to university to study medicine or inherit his family’s watch business. As he is making up his mind, he shares with the audience which clocks and mechanisms fascinate him the most. Given his passion for clockmaking and his knowledge, do you think his desire to study medicine could only be a way of rebelling against his parents’ wishes?</p>\n\n<p style=\"font-family: Times New Roman\">This game was created for research purposes as part of a MA thesis at the University of Graz. All images of objects were taken from <a href=\"https://collection.sciencemuseumgroup.org.uk/\" target=\"_blank\" rel=\"external\">The Science Museum Group&#39;s Digital Collection</a> and are linked accordingly. Texts were adapted from object descriptions and Wikipedia and are also linked.</p> \n\n<h3 id=\"hello-nice-to-meet-you-and-welcome-to-the-science-museum-\">Hello, nice to meet you and welcome to The Science Museum!</h3>\n<p><a class=\"squiffy-link link-section\" data-section=\"_continue1\" role=\"link\" tabindex=\"0\">My name is Allison and I’ll be your museum guide today.</a></p>",
		'passages': {
		},
	},
	'_continue1': {
		'text': "<p>It’s really pouring it down, isn’t it? Perfect day for a trip to the museum. </p>\n<p>Today’s exhibition is all about <strong>Clockmakers</strong> and you’ll even meet <strong>Paul</strong> and hear all about his family’s watch business and which clocks fascinate him.  </p>\n<p>But we’ll get to all of that later! First, I’d like to tell you more about the museum itself.</p>\n<p>Let’s have a look at its <a class=\"squiffy-link link-section\" data-section=\"history\" role=\"link\" tabindex=\"0\">history</a> together.</p>",
		'passages': {
		},
	},
	'history': {
		'text': "<p><a href=\"https://www.sciencemuseum.org.uk/home\" target=\"_blank\">The Science Museum</a> has its origins in the Great Exhibition of 1851, held in Hyde Park in the glass building known as the Crystal Palace.</p>\n<p>The importance of a museum dedicated to Science was recognised in the late 1800s and first decade of the 1900s. </p>\n<p>The history of the museum over the last 150 years has been one of continual change. Exhibition galleries are never static. They reflect and comment on the pace of change in science, technology, industry, and medicine. </p>\n<p>The museum is part of the Science Museum Group along with science museums in Bradford, Manchester, York, and Shildon, Co Durham. </p>\n<p>The Science Museum Group Collection has over 380,000 objects and archives. The collection includes Medicine, Railways, Art, and the Industrial Revolution. </p>\n<p>We&#39;ve prepared an <a class=\"squiffy-link link-passage\" data-passage=\"interactive timeline\" role=\"link\" tabindex=\"0\">interactive timeline</a> for you to learn more about the history of the Science Museum.</p>",
		'passages': {
			'interactive timeline': {
				'text': "<p>Sadly, the timeline is too large to be included in the game. But here&#39;s the <a href=\"https://cdn.knightlab.com/libs/timeline3/latest/embed/index.html?source=1xAgqDBePFuOKxvvye73Zdlns0dXDFZyn2Cj0DlfaShU&font=Default&lang=en&initial_zoom=2&height=650\" target=\"_blank\">link</a>, I promise it&#39;s worth looking at! The interactive timeline was created with <a href=\"http://timeline.knightlab.com/\" target=\"_blank\">this tool</a>. </p>\n<p>Now, let&#39;s focus on <a class=\"squiffy-link link-section\" data-section=\"Paul's story\" role=\"link\" tabindex=\"0\">Paul&#39;s story</a>.  </p>",
			},
		},
	},
	'Paul\'s story': {
		'text': "<h3 id=\"hi-my-name-is-paul-\">Hi! My name is Paul.</h3>\n<p>I just finished school, and now I&#39;m facing a rather difficult decision... I would love to study medicine, but all my life, I thought I would do as my father did and continue my family&#39;s watch business. </p>\n<p>I&#39;m not sure where my future will lead me, but I&#39;ve been thinking about all the stories my father told me about fascinating clockmakers and clock mechanisms. </p>\n<p>I&#39;d like to show some of the <a class=\"squiffy-link link-section\" data-section=\"mechanisms and clocks\" role=\"link\" tabindex=\"0\">mechanisms and clocks</a> that fascinate me the most today.</p>",
		'passages': {
		},
	},
	'mechanisms and clocks': {
		'text': "<p>I&#39;d like to tell you about <a class=\"squiffy-link link-section\" data-section=\"sundials\" role=\"link\" tabindex=\"0\">sundials</a> first. </p>",
		'passages': {
		},
	},
	'sundials': {
		'text': "<h3 id=\"telling-the-time-when-the-sun-is-shining-br-\"><strong>Telling the Time When the Sun is Shining:</strong> <br/></h3>\n<p><a href=\"https://imgbox.com/ouxBeHXo\" target=\"_blank\"><img src=\"https://thumbs2.imgbox.com/44/98/ouxBeHXo_t.jpg\" alt=\"imgbox\"/></a> </p>\n<p><a class=\"squiffy-link link-passage\" data-passage=\"This byzantine sundial-calendar\" role=\"link\" tabindex=\"0\">This byzantine sundial-calendar</a> was a way of telling the time by using the sun. I remember my dad taking me out to see an exhibition on clocks when I was a little boy; that&#39;s where I encountered this sundial for the first time. Its mechanism fascinates me to this day.</p>",
		'passages': {
			'This byzantine sundial-calendar': {
				'text': "<p>This sundial consists of four surviving parts (including front sundial plate, suspension arm, Moon disc with gear, and arbor with ratchet and two gear wheels). It was made in the Byzantine Empire, some time between 400-600. </p>\n<p>16 (translated) locations are inscribed in Greek on the sundial plate: Constantinople, Syene, Thebaid, Africa, Alexandria, Antioch, Rhodes, Athens, Sicily, Thessalonika, Rome, Dalmatia, Doclea, Caesarea Sratonis, Palestine, and Ascalon. </p>\n<p>This device would have been used as a sundial to tell the time in 16 locations across the ancient world. It also would have been able to predict the positions of the Sun and Moon in the zodiac and the lunar phases. </p>\n<p>Find out more about <a href=\"https://collection.sciencemuseumgroup.org.uk/objects/co1082/byzantine-sundial-calendar-sundial-perpetual-calendar\" target=\"_blank\">this object</a> over at Science Museum Group&#39;s Digital Collection.</p>\n<h3 id=\"a-later-sundial-made-by-elias-allen-br-\"><strong>A Later Sundial Made by Elias Allen:</strong> <br/></h3>\n<p><a href=\"https://imgbox.com/w7qK92GW\" target=\"_blank\"><img src=\"https://thumbs2.imgbox.com/e0/5a/w7qK92GW_t.jpg\" alt=\"imgbox\"/></a></p>\n<p><a class=\"squiffy-link link-passage\" data-passage=\"This sundial\" role=\"link\" tabindex=\"0\">This sundial</a> is a later sundial, made in the 17th century. It&#39;s stunning, isn&#39;t it?</p>",
			},
			'This sundial': {
				'text': "<p>This is a high-quality horizontal sundial. It is set out to show individual minutes and signed ‘Elias Allen fecit’. It was made in London around 1630. The dial was calculated for a latitude of 53 N, a line running roughly from Mount Snowdon to the Wash. The dial contains a mistake: the 32 point compass rose, with each point individually named, is reversed. </p>\n<p>Find out more about <a href=\"https://collection.sciencemuseumgroup.org.uk/objects/co8558686/sundial-by-elias-allen-sundial\" target=\"_blank\">this object</a> over at Science Museum Group&#39;s Digital Collection.</p>\n<p>Next, the <a class=\"squiffy-link link-section\" data-section=\"deck-watch\" role=\"link\" tabindex=\"0\">deck-watch</a> used by captain William Parry during his attempt to reach the North Pole in 1827.</p>",
			},
		},
	},
	'deck-watch': {
		'text': "<h3 id=\"the-watch-that-nearly-went-to-the-north-pole-br-\"><strong>The Watch That Nearly Went to the North Pole:</strong> <br/></h3>\n<p><a href=\"https://imgbox.com/mGFsSovP\" target=\"_blank\"><img src=\"https://thumbs2.imgbox.com/aa/df/mGFsSovP_t.jpg\" alt=\"imgbox\"/></a> </p>\n<p><a class=\"squiffy-link link-passage\" data-passage=\"This deck watch\" role=\"link\" tabindex=\"0\">This deck watch</a> was first brought up in one of my dad&#39;s many Christmas stories. Being a clockmaker, he just couldn&#39;t help himself but string a good story about a watch together with Father Christmas and his abode...</p>",
		'passages': {
			'This deck watch': {
				'text': "<p>This is the deck watch that accompanied Capt. William Parry aboard ‘Hecla’ in his attempt to reach the North Pole in June 1827. Parry used ‘sledge boats’ on the ice which proved too heavy to push. They only achieved a maximum 7 miles a day. He was forced to abandon his attempt at 82° 45&#39; latitude due to the ice moving south at a greater rate. Parry’s attempt to get to the North Pole was the furthest reached until 1876. </p>\n<p>Find out more about <a href=\"https://collection.sciencemuseumgroup.org.uk/objects/co8557898/deck-watch-used-by-capt-william-parry-during-his-attempt-to-reach-the-north-pole-1827-watch-detent\" target=\"_blank\">this object</a> over at Science Museum Group&#39;s Digital Collection.</p>\n<p>Now we&#39;ll move on to <a class=\"squiffy-link link-section\" data-section=\"chamber clocks\" role=\"link\" tabindex=\"0\">chamber clocks</a>.</p>",
			},
		},
	},
	'chamber clocks': {
		'text': "<h3 id=\"first-domestic-chamber-clocks-quite-different-from-our-clocks-br-\"><strong>First Domestic Chamber Clocks, Quite Different from Our Clocks:</strong> <br/></h3>\n<p><a href=\"https://imgbox.com/z3pAZP7x\" target=\"_blank\"><img src=\"https://thumbs2.imgbox.com/6c/d1/z3pAZP7x_t.jpg\" alt=\"imgbox\"/></a> </p>\n<p><a class=\"squiffy-link link-passage\" data-passage=\"This chamber clock\" role=\"link\" tabindex=\"0\">This chamber clock</a> was one of the earliest in use in Europe. What fascinates me is that it was almost certainly brightly painted once! I don&#39;t think it looks all that interesting now, but when you use your imagination and try to think what it might&#39;ve looked like once ... what colour would you have wanted it to be?</p>",
		'passages': {
			'This chamber clock': {
				'text': "<p>This chamber clock consisted of a forged iron frame and four corner posts. It contains a striking mechanism that operates without warning. Clocks of this sort were among the earliest in Europe for domestic use. The frame is held together with wedges, the movement regulated by a verge escapement with an adjustable bar foliot. </p>\n<p>Find out more about <a href=\"https://collection.sciencemuseumgroup.org.uk/objects/co8557995/early-domestic-weight-driven-iron-wall-clock-lantern-clock-foliot\" target=\"_blank\">this object</a> over at Science Museum Group&#39;s Digital Collection.</p>\n<p>Finally, let&#39;s have a look at a beautiful <a class=\"squiffy-link link-section\" data-section=\"bracelet watch\" role=\"link\" tabindex=\"0\">bracelet watch</a>.</p>",
			},
		},
	},
	'bracelet watch': {
		'text': "<h3 id=\"a-brilliant-bracelet-watch-that-would-look-lovely-even-today-br-\"><strong>A Brilliant Bracelet Watch that Would Look Lovely Even Today:</strong> <br/></h3>\n<p><a href=\"https://imgbox.com/nwPnawn7\" target=\"_blank\"><img src=\"https://thumbs2.imgbox.com/22/7a/nwPnawn7_t.jpg\" alt=\"imgbox\"/></a> </p>\n<p>I chose <a class=\"squiffy-link link-passage\" data-passage=\"this bracelet watch\" role=\"link\" tabindex=\"0\">this bracelet watch</a> because I simply think it&#39;s a beautiful example of how timeless watches are. It would still look great on someone&#39;s wrist today. Maybe a gift for a lovely lady?</p>\n<p><a class=\"squiffy-link link-section\" data-section=\"Let's wrap this story up!\" role=\"link\" tabindex=\"0\">Let&#39;s wrap this story up!</a></p>",
		'passages': {
			'this bracelet watch': {
				'text': "<p>Find out more about <a href=\"https://collection.sciencemuseumgroup.org.uk/objects/co8558631/bracelet-watch-by-broillal-bracelet-watch\" target=\"_blank\">this object</a> over at Science Museum Group&#39;s Digital Collection.</p>",
			},
		},
	},
	'Let\'s wrap this story up!': {
		'text': "<p>Now that you&#39;ve heard Paul&#39;s story... </p>\n<p><a class=\"squiffy-link link-section\" data-section=\"_continue2\" role=\"link\" tabindex=\"0\">I have a question for you!</a></p>",
		'passages': {
		},
	},
	'_continue2': {
		'text': "<p>What do you think was the most fascinating watch and mechanism Paul talked about?</p>",
		'passages': {
		},
	},
}
})();